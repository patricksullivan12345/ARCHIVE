# TxDOT_Project
This was apart of the project that identified crossroads based on the angles at the intersections 
